Structure from Motion (SfM)
===========================

Implementation of SfM, based on Chapter 9-12 of the book *Multiple View Geometry in Computer Vision*.

Please read the attached report for an explanation of steps taken.

sfm.py is the main entry point.
